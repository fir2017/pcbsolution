﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace pcbsolution
{
    public class stil
    {
        public stil() { }
        public Color background = Color.White;
        public Color foreground = Color.White;
        public Font fontul = new Font("Arial", 8);
    }
}
