﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pcbsolution
{
    public class pereche
    {
        public object a;
        public object b;
        public pereche() { }
        public pereche(object pa, object pb) {
            a = pa;
            b = pb;
        }

    }
}
