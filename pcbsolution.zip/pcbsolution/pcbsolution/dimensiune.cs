﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pcbsolution
{
    public class dimensiune
    {
        public float latime;
        public float lungime;
        public float inaltime;
    }
}
